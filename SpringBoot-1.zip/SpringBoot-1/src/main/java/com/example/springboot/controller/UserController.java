package com.example.springboot.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.springboot.entity.User;

@RestController
public class UserController {
	@RequestMapping("/saveUser")
	public void saveUser(@ModelAttribute("user") User user) {
		user.setUserName("rohit");
		user.setMobileNumber("6375550666");
		user.setEmail("rohitpandey@gmail.com");
		user.setStatus("true");
		
	}
}
