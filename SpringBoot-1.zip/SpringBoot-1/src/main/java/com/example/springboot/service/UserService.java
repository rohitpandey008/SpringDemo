package com.example.springboot.service;

public interface UserService {
	public void saveUser();
}
